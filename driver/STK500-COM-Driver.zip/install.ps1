$ErrorActionPreference = "Continue"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$pn = Join-Path $env:SystemRoot "System32\pnputil.exe"
Write-Host "Prolific PL-2303 3.3.2.105 설치"
$add = & $pn /add-driver (Join-Path $here "ser2pl.inf") /install 2>&1 | Out-String
Write-Host $add
$enum = & $pn /enum-drivers 2>&1 | Out-String
$blocks = [regex]::Split($enum, "(?m)(?=oem\d+\.inf)")
foreach ($b in $blocks) {
  if ($b -match "3\.9\.\d+\.\d+" -and $b -match "ser2pl|Prolific|PL-2303|PL2303") {
    $name = [regex]::Match($b, "oem\d+\.inf").Value
    if ($name) {
      Write-Host "HXA 칩을 막는 드라이버 제거: $name"
      $del = & $pn /delete-driver $name /uninstall /force 2>&1 | Out-String
      Write-Host $del
    }
  }
}
Write-Host "완료. USB 케이블을 꽂으면 COM 포트가 생깁니다."

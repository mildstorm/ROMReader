STK500 USB 시리얼 드라이버 (Prolific PL-2303 3.3.2.105)

이 PC에서 해시가 카탈로그와 맞는 것으로 확인한 드라이버입니다.
Windows Update의 3.9 드라이버는 이 칩(PL-2303HXA)을 막고 COM 포트를 열지 않습니다.

설치
1. 압축을 풉니다.
2. install.cmd 를 실행합니다. 관리자 권한 창이 뜹니다.
3. STK500 USB 케이블을 꽂습니다.
4. 장치 관리자에 Prolific USB-to-Serial Comm Port (COMx) 가 보이면 됩니다.

통신은 115200 bps 입니다. 프로그래머는 STK500v2 로 응답합니다.

보드에 전원을 따로 넣는 동안에는 프로그래머의 3.3V/5V 점퍼(J3)를 빼 둡니다.
